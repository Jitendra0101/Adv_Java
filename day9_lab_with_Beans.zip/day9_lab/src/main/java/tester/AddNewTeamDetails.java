package tester;

import static utils.HibernateUtils.getFactory;
import java.util.Scanner;
import org.hibernate.Session;
import dao.TeamDao;
import dao.TeamDaoImpl;
import pojo.Team;


public class AddNewTeamDetails {

	public static void main(String[] args) {
		
		try(Scanner sc = new Scanner(System.in)){
			
			@SuppressWarnings("unused")
			Session session=getFactory().getCurrentSession();
			TeamDao teamDao = new TeamDaoImpl();
			System.out.println("Enter team details: team_name, abberv, owner, max_Age, min_batting_avg, min_wickets_taken ");
			Team team = new Team(sc.next(),sc.next(),sc.next(),sc.nextInt(), sc.nextDouble(), sc.nextInt());
			System.out.println(teamDao.addTeamDetails(team));
			
		}catch (Exception e) {
			System.out.println("hi");
			 e.printStackTrace();
		}

	}
	
}
