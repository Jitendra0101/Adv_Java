package tester;

import java.util.Scanner;

import dao.TeamDao;
import dao.TeamDaoImpl;

public class UpdateNoOfWicketsAndBattingAvg {

	public static void main(String[] args) {

		try(Scanner sc = new Scanner(System.in)){
			
			TeamDao teamDao = new TeamDaoImpl();
			
			System.out.println("Enter Team_ID, number of wickets taken, batting avg:");
			System.out.println(teamDao.updateNoOfWicketsAndBattingAvg(sc.nextInt(),sc.nextInt(),sc.nextDouble()));
			
		}catch (Exception e) {
			 e.printStackTrace();
		}

	}

}
