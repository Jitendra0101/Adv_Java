package tester;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.Session;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojo.Team;

public class GetTeamDetailsByAbberv {

	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)){
			
			@SuppressWarnings("unused")
			Session session=getFactory().getCurrentSession();
			TeamDao teamDao = new TeamDaoImpl();
			System.out.println("Enter Team Abberv:");
			Team teamDetails = teamDao.GetTeamDetailsByAbberv(sc.next());
			System.out.println("Details of team \n" + teamDetails);
			
		} catch (Exception e) {
			e.printStackTrace();
			}
		

	}

}
