package beans;

import java.sql.SQLException;

import dao.TeamDaoImpl;
import pojo.Team;

public class TeamBeans {

	private TeamDaoImpl teamDao;
	private Team teamDetails;

	private String name;
	private String abbrev;
	private int maxAge;
	private double minBattingAvg;
	private int minWicketsTaken;
	private String owner;

	public TeamBeans() throws SQLException {
		teamDao = new TeamDaoImpl();
		System.out.println("team bean created....");
	}

	public TeamDaoImpl getTeamDao() {
		return teamDao;
	}

	public void setTeamDao(TeamDaoImpl teamDao) {
		this.teamDao = teamDao;
	}

	public Team getTeamDetails() {
		return teamDetails;
	}

	public void setTeamDetails(Team teamDetails) {
		this.teamDetails = teamDetails;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbbrev() {
		return abbrev;
	}

	public void setAbbrev(String abbrev) {
		this.abbrev = abbrev;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public double getMinBattingAvg() {
		return minBattingAvg;
	}

	public void setMinBattingAvg(double minBattingAvg) {
		this.minBattingAvg = minBattingAvg;
	}

	public int getMinWicketsTaken() {
		return minWicketsTaken;
	}

	public void setMinWicketsTaken(int minWicketsTaken) {
		this.minWicketsTaken = minWicketsTaken;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String AddNewTeam() throws SQLException {

		return teamDao.addTeamDetails(new Team(name, abbrev, owner, maxAge, minBattingAvg, minWicketsTaken));

	}

}
