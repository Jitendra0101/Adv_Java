package dao;

import pojo.Team;

public interface TeamDao {

	String addNewTeam(Team team);

}
