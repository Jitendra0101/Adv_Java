package tester;

import java.util.Scanner;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojo.Team;

public class AddNewTeamDetails {

	public static void main(String[] args) {
		
		try(Scanner sc = new Scanner(System.in)){
			
			TeamDao teamDao = new TeamDaoImpl();
			System.out.println("Enter team details: team_name, abberv, owner, max_Age, min_batting_avg, min_wickets_taken ");
			Team team = new Team(sc.next(),sc.next(),sc.next(),sc.nextInt(), sc.nextDouble(), sc.nextInt());
			System.out.println(teamDao.addTeamDetails(team));
			
		}catch (Exception e) {
			 e.printStackTrace();
		}

	}
	
}
