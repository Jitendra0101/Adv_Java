package tester;

import java.util.List;
import java.util.Scanner;

import dao.TeamDao;
import dao.TeamDaoImpl;

public class GetTeamsWithMaxAgeGreater {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {

			TeamDao teamDao = new TeamDaoImpl();
			System.out.println("Enter Age:");
			List<String> teamName = teamDao.GetTeamsWithMaxAgeGreater(sc.nextInt());
			System.out.println("Name of the team is \n" + teamName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
