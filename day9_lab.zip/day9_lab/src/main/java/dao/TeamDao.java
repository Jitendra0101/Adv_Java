package dao;
import java.util.List;

import pojo.*;



public interface TeamDao {
	public String addTeamDetails(Team newTeam);
	
	public Team GetTeamDetailsByAbberv(String abberv);
	
	public List<String> GetTeamsWithMaxAgeGreater(int age);
	
	public String updateNoOfWicketsAndBattingAvg(Integer id, int wickets, double avg);

}
