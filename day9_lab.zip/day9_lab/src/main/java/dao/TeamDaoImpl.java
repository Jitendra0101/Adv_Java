package dao;
import pojo.*;
import org.hibernate.*;
import static utils.HibernateUtils.getFactory;

import java.util.List;

public class TeamDaoImpl implements TeamDao {
	
	@Override
	public String addTeamDetails(Team newTeam) {
		Session session=getFactory().getCurrentSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(newTeam);
			tx.commit();
		}catch (RuntimeException e) {
			//rollback txn
			if(tx!=null)
				tx.rollback();
			throw e;
		}finally {
			if(session!=null)
				session.close();
		}
		return "Added new team with Id"+newTeam.getTeamId();
		
	}

	@Override
	public Team GetTeamDetailsByAbberv(String abberv) {
		
		Team t = null;
		String jpql = "select t from Team t where t.abbreviation=:abbr";
		
		Session session = getFactory().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		
		try {
			
			t = session.createQuery(jpql, Team.class).setParameter("abbr",abberv).getSingleResult();
			tx.commit();
			
		} catch (RuntimeException e) {
		
			if(tx != null)
				tx.rollback();
			throw e;	
		}
		
		return t;
	}

	@Override
	public List<String> GetTeamsWithMaxAgeGreater(int age) {
	
		List<String> teamNames;
		String jpql = "select t.name from Team t where t.maxAge>:age";
		Session session = getFactory().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		
		try {
			
			teamNames = session.createQuery(jpql, String.class).setParameter("age", age).getResultList();
			tx.commit();
			
		} catch (RuntimeException e) {
			 
			if(tx != null)
				tx.rollback();
			throw e;
			
		}
		
		return teamNames;
	}

	@Override
	public String updateNoOfWicketsAndBattingAvg(Integer id, int wickets, double avg) {
		
		String mesg = "Updation failed !!";
		Team team = null;
		
		Session session = getFactory().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		
		try {
			
			team = session.get(Team.class,id);
			
			team.setMinWicketsTaken(wickets);
			team.setMinBattingAvg(avg);
			
			tx.commit();
			mesg = "Successfully updated !!";
			
		} catch (RuntimeException e) {
			 
			if(tx != null)
				tx.rollback();
			throw e;
			
		}
		
		
		return mesg;
	}

}
